run make on Makefile to compile

to run ./comander < "input.txt"
